#ifndef GIAFATTO_PROCEDURE
#define GIAFATTO_PROCEDURE


#define TOT_MERENDINE (7)

void InputMacchinetta(float* euro, int* cod);
void CalcoliMacchinetta(int code, int* index);
void RisultatiMacchinetta(int ind, float soldi, float* mancia);


#endif

