#include <stdio.h>
#include <string.h>

#include "procedure.h"

extern int codici[];
extern float prezzi_merendine[];
extern char nomi_merendine[][30];

void InputMacchinetta(float* euro, int* cod)
{
  int k;

    do
    {
      printf("Inserire l'importo: ");
      k = scanf("%f", euro);  // quando scanf() ritorna 1, allora � ok
      fflush(stdin);  // nessun problema, stdin � GLOBALE (fa parte del C)
    }
    while (k!=1);  //

    do
    {
      printf("Inserire il codice della merendina: ");
      k = scanf("%d", cod);
      fflush(stdin);
    }
    while (k!=1);
}




void CalcoliMacchinetta(int code, int* index)
{
  int i;

    *index = -1;
    // Individuo l'indice della merendina scelta
    for (i=0; i<TOT_MERENDINE; i++)
    {
      if (code==codici[i])
      {
        break;
      }
    }
    *index = i;
}

void RisultatiMacchinetta(int ind, float soldi, float* mancia)
{
    if (ind==TOT_MERENDINE  || soldi < prezzi_merendine[ind])
    {
      *mancia = soldi;
      printf("\nMerendina: -");
    }
    else
    {
      printf("Merendina: %s", nomi_merendine[ind]);
      *mancia = soldi - prezzi_merendine[ind];
    }

    printf("\nResto: %.1f\n\n", *mancia);

}
