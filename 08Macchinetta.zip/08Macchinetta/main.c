
#include <stdio.h>
#include <string.h>

#include "procedure.h"


int codici[TOT_MERENDINE];
float prezzi_merendine[TOT_MERENDINE];
char nomi_merendine[TOT_MERENDINE][30];  // array bidimensionale





int main()
{

  // DICHIARAZIONI
  float importo;
  float resto;
  int codice;
  int indice_merendina;


  // ASSEGNAZIONI
  indice_merendina = 0;
  importo = -1.0;
  resto = 0.0;
  prezzi_merendine[0] =0.6;
  prezzi_merendine[1] =0.8;
  prezzi_merendine[2] =0.9;
  prezzi_merendine[3] =0.8;
  prezzi_merendine[4] =1.8;
  prezzi_merendine[5] =0.8;
  prezzi_merendine[6] =1.0;

  strcpy(nomi_merendine[0], "Cipster");
  strcpy(nomi_merendine[1], "ZenMix");
  strcpy(nomi_merendine[2], "Ringo");
  strcpy(nomi_merendine[3], "Lyon");
  strcpy(nomi_merendine[4], "KitKat");
  strcpy(nomi_merendine[5], "TUC");
  strcpy(nomi_merendine[6], "Kinder Bueno");

  codice = 0;
  codici[0] = 1;
  codici[1] = 2;
  codici[2] = 3;
  codici[3] = 4;
  codici[4] = 5;
  codici[5] = 6;
  codici[6] = 7;


  // Ciclo multi erogazione
  while (importo!=0)
  {

    // INPUT
    InputMacchinetta(&importo, &codice); // importo e codice sono i parametri ATTUALI

    // CALCOLI
    CalcoliMacchinetta(codice, &indice_merendina);

    // OUTPUT
    RisultatiMacchinetta(indice_merendina, importo, &resto);

  }

  return 0;
}

